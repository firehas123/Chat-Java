package com.muc;

/**
 * Created by jim on 4/21/17.
 */
public interface MessageListener {
    public void onMessage(String fromLogin, String msgBody);
}
